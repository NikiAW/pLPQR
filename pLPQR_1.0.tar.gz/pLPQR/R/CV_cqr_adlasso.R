#' @title Cross-validation for penalized longitudinal parametric quantile regression
#' @description Penalized longitudinal parametric quantile regression via cross validation
#' @param x the covariate matrix, with rows sorted primarily by country and secondarily by year
#' @param y the corresponding response vector
#' @param nsub the number of subjects
#' @param nk the number of observations for each subject
#' @param bf the known functions b(tau)
#' @param bderivf the derivative of the known functions b(tau)
#' @param gammaint initial estimates of the unknown coefficient matrix
#' @param lambda the tuning parameter in pLPQR
#' @param type working correlation matrix with "cs" indicating the normal copula with an exchangeable correlation matrix, "ar" indicating the normal copula with an autoregressive structure of order 1, and "wi" indicating the working independence
#' @param tau a finite number of grid points between 0 and 1
#' @param nt the length of tau
#' @param rho a constant penalty parameter
#'
#' @returns a \code{list} of estimation results, containing gamma (a vector of the optimal pLPQR estimates for the vectorized coefficient matrix selected by minimizing the QIFBIC criterion), QIFBIC (the optimal QIFBIC value), lambda (the optimal tuning parameter), a list of pLPQR estimations for the optimal lambda, and a list of all the pLPQR estimations for all lambda's.
#' @export
#'
#' @examples
#' # Note:
#' library(copula); library(qrcm)
#' bf <- function(xx){return(c(1,qnorm(xx)))}
#' bderivf <- function(xx){return(c(0,1/dnorm(xx)))}; K <- 2;
#' theta <- matrix(c(0,2,1,0,3,1,rep(0,4)),ncol=K); p <- nrow(theta); nsub <- 500; m <- 5
#' nk <- m*rep(1,nsub); index <- rep(1:m,nsub);Rho=0.8; n=nsub*m
#' R <- matrix(NA,(p-1),(p-1)); Rho <- 0.8
#' for(i in 1:(p-1)){
#'   for(j in 1:(p-1)){
#'     R[i,j] <- Rho^abs(i-j)
#'   }
#' }
#' x <- matrix(1,nrow=n,ncol=1)
#' for(j in 1:(p-1)){
#'   x <- cbind(x,runif(n,min=(j-1)/5,max=1+(j-1)/5))
#' }
#' R <- (1-Rho)*diag(m)+Rho*matrix(1,m,m)
#' qe <- c(t(rCopula(nsub, normalCopula(param = P2p(R), dim = m, dispstr = "un"))))
#' beta0 <- lapply(qe,function(xx){theta %*% bf(xx)})
#' y <- NULL
#' for(ii in 1:n){
#'   y <- c(y,x[ii,]%*%beta0[[ii]])
#' }
#' gammaint <- iqr(y~ -1 + x, formula.p = ~ I(qnorm(p)))
#' gammaint=c(gammaint$coefficients)
#' CV_cqr_adlasso(x, y, nsub,nk, bf, bderivf, gammaint=c(gammaint$coefficients))

CV_cqr_adlasso <- function(x,  # the covariate matrix, with rows sorted primarily by country and secondarily by year
                           y,  # the corresponding response vector
                           nsub, # the number of subjects
                           nk,   # the number of observations for each subject
                           bf,   # the known functions b(tau)
                           bderivf,  # the derivative of the known functions b(tau)
                           gammaint,  # initial estimates of the unknown coefficient matrix
                           lambda=seq(1,0.1,-0.1),  # the tuning parameter in pLPQR
                           type="cs",  # working correlation matrix with "cs" indicating the normal copula with an exchangeable correlation matrix, "ar" indicating the normal copula with an autoregressive structure of order 1, and "wi" indicating the working independence
                           tau=seq(0.01,0.99,0.01),
                           nt=length(tau),  # the number of tau's
                           rho=0.01  # a constant penalty parameter
){
# sourceCpp("D:/BaiduNetdiskDownload/BaiduSyncdisk/0 UIBE/paper/PLPQR/JASA/Revise1/Data_Code_for_PLPQR/pLPQR/pLPQR/src/PQR_Pen.cpp")

  # nsub <- length(unique(index$country))  # 170 countries
  # nk <- c(table(index$country))  # 20
  rowindex=c(0,cumsum(nk))  # the starting row index minus 1 for each country
  btau=sapply(tau,bf)
  bderiv=sapply(tau,bderivf)
  K=length(bf(0))
  wt=rep(1,length(tau))

  result <- cv_cqr_adlasso(type,lambda, x,y, nk, tau, nsub,nt, gammaint, rho, btau, bderiv, K, wt)
  return(result)
}

