
## example of simple test that always succeeds
expect_equal(1 + 1, 2)

## test of placeholder function hello()
expect_stdout(hello(), "Hello, world")
expect_stdout(hello("kitty"), "Hello, kitty")
